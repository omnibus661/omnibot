# omnibot
Semi-Automation of schema.org's Microdata system

Requires at least Python 3.6


To start use omni.bat

Use typelist.txt as reference sheet

use_me.html is an example file to import